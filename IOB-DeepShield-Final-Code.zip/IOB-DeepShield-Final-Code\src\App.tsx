import { useEffect, useMemo, useRef, useState } from 'react'
import {
  Activity,
  AlertTriangle,
  BadgeCheck,
  Camera,
  CheckCircle2,
  Eye,
  Gauge,
  LockKeyhole,
  Play,
  Radar,
  ScanFace,
  ShieldAlert,
  ShieldCheck,
  Square,
  Waves,
  XCircle,
} from 'lucide-react'
import './App.css'

declare const FaceMesh: any

type PromptKey = 'straight' | 'left' | 'right' | 'blink' | 'smile' | 'still'
type Verdict = 'WAITING' | 'SCANNING' | 'REAL_HUMAN' | 'RISKY_OR_DEEPFAKE'

type Prompt = {
  key: PromptKey
  label: string
  hint: string
  seconds: number
}

type Metrics = {
  faceFrames: number
  brightness: number
  contrast: number
  yaw: number
  yawRange: number
  blinkRatio: number
  smileRatio: number
  motion: number
  textureScore: number
  replayScore: number
  parallaxScore: number
  livenessScore: number
  rppgScore: number
  trustScore: number
  fraudProbability: number
}

const IOB_LOGO = '/iob-logo.png'
const DEEPSHIELD_LOGO = '/deepshield-logo.png'

const prompts: Prompt[] = [
  { key: 'straight', label: 'Look straight', hint: 'Center your face inside the scanner', seconds: 3 },
  { key: 'left', label: 'Turn head left', hint: 'Move slowly so parallax can be measured', seconds: 3 },
  { key: 'right', label: 'Turn head right', hint: 'Return through center and turn right', seconds: 3 },
  { key: 'blink', label: 'Blink once', hint: 'Blink after the beep-style prompt appears', seconds: 2 },
  { key: 'smile', label: 'Smile', hint: 'Natural mouth movement is checked', seconds: 2 },
  { key: 'still', label: 'Stay still', hint: 'Hold for rPPG pulse estimation', seconds: 5 },
]

const initialMetrics: Metrics = {
  faceFrames: 0,
  brightness: 0,
  contrast: 0,
  yaw: 0,
  yawRange: 0,
  blinkRatio: 0,
  smileRatio: 0,
  motion: 0,
  textureScore: 0,
  replayScore: 0,
  parallaxScore: 0,
  livenessScore: 0,
  rppgScore: 0,
  trustScore: 0,
  fraudProbability: 0,
}

function clamp(value: number, min = 0, max = 100) {
  return Math.max(min, Math.min(max, value))
}

function scoreFromRange(value: number, low: number, high: number) {
  return clamp(((value - low) / (high - low)) * 100)
}

function average(values: number[]) {
  if (!values.length) return 0
  return values.reduce((sum, value) => sum + value, 0) / values.length
}

function variance(values: number[]) {
  const mean = average(values)
  return average(values.map((value) => (value - mean) ** 2))
}

function getEyeRatio(lms: any[], left: boolean) {
  const outer = lms[left ? 33 : 263]
  const inner = lms[left ? 133 : 362]
  const top = lms[left ? 159 : 386]
  const bottom = lms[left ? 145 : 374]
  const width = Math.hypot(outer.x - inner.x, outer.y - inner.y)
  const height = Math.hypot(top.x - bottom.x, top.y - bottom.y)
  return height / (width + 0.0001)
}

function getSmileRatio(lms: any[]) {
  const left = lms[61]
  const right = lms[291]
  const top = lms[13]
  const bottom = lms[14]
  const mouthWidth = Math.hypot(left.x - right.x, left.y - right.y)
  const mouthOpen = Math.hypot(top.x - bottom.x, top.y - bottom.y)
  return mouthWidth / (mouthOpen + 0.0001)
}

function estimatePulse(samples: number[]) {
  if (samples.length < 45) return 0
  const centered = samples.map((value) => value - average(samples))
  const signalPower = Math.sqrt(variance(centered))
  let bestPower = 0

  for (let hz = 0.7; hz <= 4; hz += 0.1) {
    let real = 0
    let imag = 0
    for (let i = 0; i < centered.length; i += 1) {
      const angle = (2 * Math.PI * hz * i) / 15
      real += centered[i] * Math.cos(angle)
      imag -= centered[i] * Math.sin(angle)
    }
    bestPower = Math.max(bestPower, Math.sqrt(real * real + imag * imag) / centered.length)
  }

  if (signalPower < 0.4) return 8
  return Math.round(clamp((bestPower / (signalPower + 0.0001)) * 135))
}

function analyzeFrame(
  video: HTMLVideoElement,
  canvas: HTMLCanvasElement,
  landmarks: any[],
  greenSamples: number[],
) {
  const ctx = canvas.getContext('2d', { willReadFrequently: true })
  if (!ctx) return null

  const width = video.videoWidth || 640
  const height = video.videoHeight || 480
  canvas.width = width
  canvas.height = height
  ctx.drawImage(video, 0, 0, width, height)

  const xs = landmarks.map((lm) => lm.x * width)
  const ys = landmarks.map((lm) => lm.y * height)
  const minX = clamp(Math.min(...xs) - 20, 0, width - 1)
  const maxX = clamp(Math.max(...xs) + 20, 1, width)
  const minY = clamp(Math.min(...ys) - 20, 0, height - 1)
  const maxY = clamp(Math.max(...ys) + 20, 1, height)
  const faceW = Math.max(8, maxX - minX)
  const faceH = Math.max(8, maxY - minY)
  const image = ctx.getImageData(minX, minY, faceW, faceH)
  const data = image.data

  let lumSum = 0
  let chromaSum = 0
  let textureSum = 0
  let lastLum = 0
  let count = 0

  for (let i = 0; i < data.length; i += 16) {
    const r = data[i]
    const g = data[i + 1]
    const b = data[i + 2]
    const y = 0.299 * r + 0.587 * g + 0.114 * b
    const cb = 128 - 0.168736 * r - 0.331264 * g + 0.5 * b
    const cr = 128 + 0.5 * r - 0.418688 * g - 0.081312 * b
    lumSum += y
    chromaSum += Math.abs(cb - 128) + Math.abs(cr - 128)
    if (count > 0) textureSum += Math.abs(y - lastLum)
    lastLum = y
    count += 1
  }

  const brightness = Math.round((lumSum / Math.max(1, count) / 255) * 100)
  const contrast = Math.round(clamp(Math.sqrt(variance(Array.from({ length: Math.min(300, count) }, (_, idx) => {
    const i = idx * 16
    return data[i] ? 0.299 * data[i] + 0.587 * data[i + 1] + 0.114 * data[i + 2] : 0
  }))) / 1.2))
  const texture = textureSum / Math.max(1, count)
  const textureScore = Math.round(clamp(100 - Math.abs(texture - 18) * 3.2))
  const replayScore = Math.round(clamp(100 - Math.max(0, chromaSum / Math.max(1, count) - 34) * 2.6))

  const forehead = landmarks[10]
  const fx = clamp(forehead.x * width - 18, 0, width - 36)
  const fy = clamp(forehead.y * height + 8, 0, height - 22)
  const patch = ctx.getImageData(fx, fy, 36, 22).data
  let green = 0
  for (let i = 0; i < patch.length; i += 4) green += patch[i + 1]
  greenSamples.push(green / (patch.length / 4))
  if (greenSamples.length > 120) greenSamples.shift()

  return { brightness, contrast, textureScore, replayScore }
}

function drawOverlay(canvas: HTMLCanvasElement, landmarks: any[]) {
  const ctx = canvas.getContext('2d')
  if (!ctx) return
  const width = canvas.width
  const height = canvas.height

  ctx.strokeStyle = 'rgba(48, 213, 255, 0.8)'
  ctx.lineWidth = 2
  ctx.fillStyle = 'rgba(64, 249, 155, 0.85)'

  ;[1, 10, 33, 61, 133, 145, 152, 159, 263, 291, 362, 374, 386, 454].forEach((idx) => {
    const lm = landmarks[idx]
    if (!lm) return
    ctx.beginPath()
    ctx.arc(lm.x * width, lm.y * height, 3, 0, Math.PI * 2)
    ctx.fill()
  })

  ctx.strokeRect(width * 0.18, height * 0.1, width * 0.64, height * 0.78)
}

function MetricCard({ icon, label, value, unit }: { icon: React.ReactNode; label: string; value: number; unit?: string }) {
  return (
    <div className="live-metric">
      <div>{icon}</div>
      <span>{label}</span>
      <strong>{Math.round(value)}{unit ?? ''}</strong>
      <div className="signal-bar__track">
        <div style={{ width: `${clamp(value)}%` }} />
      </div>
    </div>
  )
}

function getCameraErrorMessage(error: unknown) {
  if (!window.isSecureContext && window.location.hostname !== '127.0.0.1' && window.location.hostname !== 'localhost') {
    return 'Camera needs HTTPS or localhost. Open the app using http://127.0.0.1:5173/.'
  }

  const name = error instanceof DOMException ? error.name : ''
  if (name === 'NotAllowedError' || name === 'SecurityError') {
    return 'Camera permission was blocked. Allow camera access from the browser permission icon, then retry.'
  }
  if (name === 'NotFoundError' || name === 'DevicesNotFoundError') {
    return 'No webcam found. Connect a camera and retry.'
  }
  if (name === 'NotReadableError' || name === 'TrackStartError') {
    return 'Camera is busy in another app. Close Zoom/OBS/Teams or any camera app, then retry.'
  }
  if (name === 'OverconstrainedError' || name === 'ConstraintNotSatisfiedError') {
    return 'Camera does not support the requested mode. Retrying with a basic camera profile may help.'
  }

  return 'Camera could not start. Check browser permission and retry.'
}

function App() {
  const videoRef = useRef<HTMLVideoElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const faceMeshRef = useRef<any>(null)
  const streamRef = useRef<MediaStream | null>(null)
  const rafRef = useRef<number | null>(null)
  const promptStartedAtRef = useRef(0)
  const promptIndexRef = useRef(0)
  const faceFramesRef = useRef(0)
  const yawHistoryRef = useRef<number[]>([])
  const movementHistoryRef = useRef<number[]>([])
  const greenSamplesRef = useRef<number[]>([])
  const prevNoseRef = useRef<{ x: number; y: number } | null>(null)
  const baselineBlinkRef = useRef<number | null>(null)
  const baselineSmileRef = useRef<number | null>(null)
  const passedRef = useRef<Record<PromptKey, boolean>>({
    straight: false,
    left: false,
    right: false,
    blink: false,
    smile: false,
    still: false,
  })

  const [ready, setReady] = useState(false)
  const [running, setRunning] = useState(false)
  const [promptIndex, setPromptIndex] = useState(0)
  const [passed, setPassed] = useState(passedRef.current)
  const [metrics, setMetrics] = useState<Metrics>(initialMetrics)
  const [verdict, setVerdict] = useState<Verdict>('WAITING')
  const [flags, setFlags] = useState<string[]>(['Camera not started'])
  const [error, setError] = useState('')

  const activePrompt = prompts[promptIndex]

  useEffect(() => {
    promptIndexRef.current = promptIndex
  }, [promptIndex])

  useEffect(() => {
    let cancelled = false

    const init = () => {
      if (typeof FaceMesh === 'undefined') {
        window.setTimeout(init, 300)
        return
      }

      const mesh = new FaceMesh({
        locateFile: (file: string) => `https://cdn.jsdelivr.net/npm/@mediapipe/face_mesh/${file}`,
      })
      mesh.setOptions({
        maxNumFaces: 1,
        refineLandmarks: true,
        minDetectionConfidence: 0.55,
        minTrackingConfidence: 0.55,
      })
      mesh.onResults((result: any) => {
        if (cancelled) return
        const landmarks = result.multiFaceLandmarks?.[0]
        if (!landmarks || !videoRef.current || !canvasRef.current) {
          setFlags(['No face detected'])
          return
        }
        processLandmarks(landmarks)
      })
      faceMeshRef.current = mesh
      setReady(true)
      if (streamRef.current && !rafRef.current) {
        loop()
      }
    }

    init()
    return () => {
      cancelled = true
      stop()
    }
  }, [])

  useEffect(() => {
    if (!running) return
    promptStartedAtRef.current = performance.now()
    const id = window.setInterval(() => {
      setPromptIndex((current) => {
        const next = current + 1
        promptStartedAtRef.current = performance.now()
        if (next >= prompts.length) {
          window.clearInterval(id)
          return current
        }
        return next
      })
    }, activePrompt.seconds * 1000)

    return () => window.clearInterval(id)
  }, [running])

  const output = useMemo(() => ({
    engine: 'VID-LIVE',
    verdict,
    trust_score: Math.round(metrics.trustScore),
    fraud_probability: Math.round(metrics.fraudProbability),
    face_frames: metrics.faceFrames,
    liveness_passed: Object.values(passed).filter(Boolean).length,
    liveness_total: prompts.length,
    parallax_score: Math.round(metrics.parallaxScore),
    rppg_score: Math.round(metrics.rppgScore),
    artifact_texture_score: Math.round(metrics.textureScore),
    replay_surface_score: Math.round(metrics.replayScore),
    flags,
  }), [flags, metrics, passed, verdict])

  async function start() {
    setError('')
    stop()
    resetSession()
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { width: 960, height: 720, facingMode: 'user' },
        audio: false,
      })
      streamRef.current = stream
      if (videoRef.current) {
        videoRef.current.srcObject = stream
        await videoRef.current.play()
      }
      setRunning(true)
      setVerdict('SCANNING')
      if (faceMeshRef.current) {
        loop()
      } else {
        setFlags(['Camera preview is live. AI engine is still loading.'])
      }
    } catch (cameraError) {
      setVerdict('WAITING')
      setFlags(['Camera not started'])
      setError(getCameraErrorMessage(cameraError))
    }
  }

  function stop() {
    if (rafRef.current) cancelAnimationFrame(rafRef.current)
    rafRef.current = null
    streamRef.current?.getTracks().forEach((track) => track.stop())
    streamRef.current = null
    if (videoRef.current) {
      videoRef.current.srcObject = null
    }
    setRunning(false)
  }

  async function loop() {
    if (!streamRef.current) return
    if (videoRef.current && faceMeshRef.current && videoRef.current.readyState >= 2) {
      await faceMeshRef.current.send({ image: videoRef.current })
    }
    rafRef.current = requestAnimationFrame(loop)
  }

  function resetSession() {
    yawHistoryRef.current = []
    movementHistoryRef.current = []
    greenSamplesRef.current = []
    faceFramesRef.current = 0
    prevNoseRef.current = null
    baselineBlinkRef.current = null
    baselineSmileRef.current = null
    passedRef.current = { straight: false, left: false, right: false, blink: false, smile: false, still: false }
    setPassed(passedRef.current)
    setPromptIndex(0)
    setMetrics(initialMetrics)
    setFlags([])
    setVerdict('SCANNING')
  }

  function markPassed(key: PromptKey) {
    if (passedRef.current[key]) return
    passedRef.current = { ...passedRef.current, [key]: true }
    setPassed(passedRef.current)
  }

  function processLandmarks(lms: any[]) {
    const video = videoRef.current
    const canvas = canvasRef.current
    if (!video || !canvas) return

    const frame = analyzeFrame(video, canvas, lms, greenSamplesRef.current)
    if (!frame) return
    drawOverlay(canvas, lms)

    const nose = lms[1]
    const leftEar = lms[234]
    const rightEar = lms[454]
    const dLeft = Math.hypot(nose.x - leftEar.x, nose.y - leftEar.y)
    const dRight = Math.hypot(nose.x - rightEar.x, nose.y - rightEar.y)
    const yaw = dLeft / (dRight + 0.0001)

    const blinkRatio = (getEyeRatio(lms, true) + getEyeRatio(lms, false)) / 2
    const smileRatio = getSmileRatio(lms)
    baselineBlinkRef.current = baselineBlinkRef.current ?? blinkRatio
    baselineSmileRef.current = baselineSmileRef.current ?? smileRatio

    const prevNose = prevNoseRef.current
    const motion = prevNose ? Math.hypot(nose.x - prevNose.x, nose.y - prevNose.y) : 0
    prevNoseRef.current = { x: nose.x, y: nose.y }

    yawHistoryRef.current.push(yaw)
    movementHistoryRef.current.push(motion)
    if (yawHistoryRef.current.length > 160) yawHistoryRef.current.shift()
    if (movementHistoryRef.current.length > 120) movementHistoryRef.current.shift()

    const currentPrompt = prompts[promptIndexRef.current]
    if (currentPrompt.key === 'straight' && Math.abs(yaw - 1) < 0.16) markPassed('straight')
    if (currentPrompt.key === 'left' && yaw > 1.18) markPassed('left')
    if (currentPrompt.key === 'right' && yaw < 0.86) markPassed('right')
    if (currentPrompt.key === 'blink' && blinkRatio < (baselineBlinkRef.current ?? blinkRatio) * 0.68) markPassed('blink')
    if (currentPrompt.key === 'smile' && smileRatio > (baselineSmileRef.current ?? smileRatio) * 1.14) markPassed('smile')
    if (currentPrompt.key === 'still' && average(movementHistoryRef.current.slice(-25)) < 0.0038) markPassed('still')

    const yawRange = Math.max(...yawHistoryRef.current) - Math.min(...yawHistoryRef.current)
    const parallaxScore = scoreFromRange(yawRange, 0.18, 0.72)
    const livenessScore = (Object.values(passedRef.current).filter(Boolean).length / prompts.length) * 100
    const rppgScore = estimatePulse(greenSamplesRef.current)
    const qualityScore = frame.brightness >= 25 && frame.brightness <= 85 ? 88 : 42
    const antiSpoofScore = average([frame.textureScore, frame.replayScore, qualityScore])
    const trustScore = clamp(
      livenessScore * 0.34 +
      parallaxScore * 0.24 +
      rppgScore * 0.18 +
      antiSpoofScore * 0.24,
    )
    const fraudProbability = 100 - trustScore
    const nextFlags: string[] = []

    if (frame.brightness < 25 || frame.brightness > 85) nextFlags.push('Lighting not normalized enough')
    if (frame.textureScore < 45) nextFlags.push('Synthetic or compressed texture pattern')
    if (frame.replayScore < 45) nextFlags.push('Possible screen replay surface')
    if (parallaxScore < 45) nextFlags.push('Weak 3D parallax, possible flat video/photo')
    if (livenessScore < 70) nextFlags.push('Liveness prompts incomplete')
    if (currentPrompt.key === 'still' && rppgScore < 35) nextFlags.push('Pulse signal not confirmed yet')

    faceFramesRef.current += 1

    setMetrics((previous) => ({
      faceFrames: previous.faceFrames + 1,
      brightness: frame.brightness,
      contrast: frame.contrast,
      yaw,
      yawRange,
      blinkRatio,
      smileRatio,
      motion,
      textureScore: frame.textureScore,
      replayScore: frame.replayScore,
      parallaxScore,
      livenessScore,
      rppgScore,
      trustScore,
      fraudProbability,
    }))
    setFlags(nextFlags.length ? nextFlags : ['All live signals currently healthy'])

    if (Object.values(passedRef.current).every(Boolean) && faceFramesRef.current > 70) {
      setVerdict(trustScore >= 72 ? 'REAL_HUMAN' : 'RISKY_OR_DEEPFAKE')
    } else {
      setVerdict('SCANNING')
    }
  }

  const verdictClass = verdict === 'REAL_HUMAN' ? 'is-granted' : verdict === 'RISKY_OR_DEEPFAKE' ? 'is-blocked' : ''
  const passCount = Object.values(passed).filter(Boolean).length

  return (
    <main className={`app-shell live-app ${verdictClass}`}>
      <nav className="topbar">
        <div className="brand">
          <div className="brand-logo-stack" aria-label="IOB and DeepShield logos">
            <img src={IOB_LOGO} alt="Indian Overseas Bank" className="brand-logo brand-logo--iob" />
            <img src={DEEPSHIELD_LOGO} alt="DeepShield" className="brand-logo brand-logo--shield" />
          </div>
          <div>
            <strong>IOB DeepShield</strong>
            <span>VID-LIVE by Team ORVIX</span>
          </div>
        </div>
        <div className="nav-pills" aria-label="Live detector sections">
          <a href="#detector">Live Detector</a>
          <a href="#signals">Signals</a>
          <a href="#output">Output</a>
        </div>
        <button className="icon-button" aria-label="Secure session"><LockKeyhole size={18} /></button>
      </nav>

      <section className="hero-grid live-hero" id="detector">
        <div className="hero-copy">
          <div className="hero-logo-card tilt-card">
            <img src={IOB_LOGO} alt="Indian Overseas Bank" />
            <div className="hero-logo-divider" />
            <img src={DEEPSHIELD_LOGO} alt="DeepShield" />
          </div>
          <div className="status-chip"><Radar size={16} /> Live camera security scan</div>
          <h1>Secure banking login with real-time face protection.</h1>
          <p>
            Start the camera, follow simple face prompts, and DeepShield checks whether the person
            is live before granting banking access.
          </p>
          <div className="quick-steps" aria-label="How to use DeepShield">
            <span>1. Allow camera</span>
            <span>2. Center face</span>
            <span>3. Follow prompts</span>
            <span>4. Get result</span>
          </div>
          <div className="hero-actions">
            <button className="primary-action" onClick={start} disabled={running}>
              <Play size={18} /> Start Camera Scan
            </button>
            <button className="danger-action" onClick={stop} disabled={!running}>
              <Square size={18} /> Stop camera
            </button>
          </div>
          {error && (
            <div className="error-banner">
              <span>{error}</span>
              <button onClick={start}>Retry camera</button>
            </div>
          )}
          {!ready && !error && (
            <div className="engine-note">Camera can start now. AI face engine is loading in the background.</div>
          )}
          <div className="feature-strip">
            <span><Camera size={16} /> WebRTC webcam</span>
            <span><ScanFace size={16} /> MediaPipe FaceMesh</span>
            <span><Waves size={16} /> rPPG pulse</span>
            <span><ShieldAlert size={16} /> Spoof risk flags</span>
          </div>
        </div>

        <div className="scanner-panel live-console">
          <div className="scanner-header">
            <span>Current instruction</span>
            <b>{verdict}</b>
          </div>
          <div className="video-stage">
            <video ref={videoRef} playsInline muted />
            <canvas ref={canvasRef} />
            <div className="scanner-beam live-beam" />
            {!running && (
              <div className="camera-placeholder">
                <img src={DEEPSHIELD_LOGO} alt="" />
                <strong>Camera standby</strong>
                <span>Click Start Camera Scan and allow permission</span>
              </div>
            )}
            <div className="live-instruction">
              <span>{activePrompt.hint}</span>
              <strong>{activePrompt.label}</strong>
            </div>
          </div>
          <div className="decision-grid">
            <div className="risk-summary">
              <span>Trust score</span>
              <strong>{Math.round(metrics.trustScore)}</strong>
              <p>{passCount}/{prompts.length} prompts passed</p>
            </div>
            <div className="risk-summary">
              <span>Fraud probability</span>
              <strong>{Math.round(metrics.fraudProbability)}%</strong>
              <p>{metrics.faceFrames} analyzed face frames</p>
            </div>
            <div className="risk-summary">
              <span>Final decision</span>
              <strong>{verdict}</strong>
              <p>{flags[0]}</p>
            </div>
          </div>
        </div>
      </section>

      <section className="verification-flow">
        <div className="section-title">
          <span>Complete Authentication Flow</span>
          <h2>10-15 second interactive liveness challenge</h2>
          <p>Each step is validated from live facial landmarks, not from a scripted UI state.</p>
        </div>
        <div className="flow-grid">
          {prompts.map((prompt, index) => (
            <div className={`flow-step ${promptIndex === index && running ? 'active' : ''}`} key={prompt.key}>
              <b>{passed[prompt.key] ? 'PASS' : String(index + 1).padStart(2, '0')}</b>
              <span>{prompt.label}</span>
            </div>
          ))}
        </div>
      </section>

      <section className="dashboard-section" id="signals">
        <div className="section-title">
          <span>Real-Time Signals</span>
          <h2>Frame preprocessing, parallax, artifacts, pulse, and risk fusion</h2>
          <p>Scores update continuously while the webcam stream is running.</p>
        </div>
        <div className="live-metric-grid">
          <MetricCard icon={<Activity size={18} />} label="Brightness" value={metrics.brightness} />
          <MetricCard icon={<Gauge size={18} />} label="Contrast" value={metrics.contrast} />
          <MetricCard icon={<ScanFace size={18} />} label="Parallax" value={metrics.parallaxScore} />
          <MetricCard icon={<BadgeCheck size={18} />} label="Liveness" value={metrics.livenessScore} />
          <MetricCard icon={<Waves size={18} />} label="rPPG pulse" value={metrics.rppgScore} />
          <MetricCard icon={<Eye size={18} />} label="Texture naturalness" value={metrics.textureScore} />
          <MetricCard icon={<AlertTriangle size={18} />} label="Replay resistance" value={metrics.replayScore} />
          <MetricCard icon={<CheckCircle2 size={18} />} label="Trust" value={metrics.trustScore} />
        </div>
        <div className="glass-panel flag-panel">
          <h3>Live AI / Deepfake Risk Flags</h3>
          {flags.map((flag) => (
            <div className="flag-row" key={flag}>
              {flag.includes('healthy') ? <CheckCircle2 size={18} /> : <XCircle size={18} />}
              <span>{flag}</span>
            </div>
          ))}
        </div>
      </section>

      <section className="architecture-section" id="output">
        <div className="section-title">
          <span>Banking API Output</span>
          <h2>Use this JSON as the FastAPI response contract</h2>
          <p>Connect the frontend to a trained CNN-LSTM or Transformer model by replacing only the artifact score service.</p>
        </div>
        <pre className="output-json">{JSON.stringify(output, null, 2)}</pre>
      </section>
    </main>
  )
}

export default App
