# IOB DeepShield Handoff

## App Link

Local demo URL: http://127.0.0.1:5173/

Run commands:

```bash
npm install
npm run dev -- --host 127.0.0.1 --port 5173
npm run build
```

## Model Training Output

This repository now contains a hackathon-ready frontend prototype and simulated AI risk engine output. A real production deepfake model was not trained here because that requires a labeled video dataset, GPU time, and model validation. For the demo, the UI presents the expected model output format and decision flow.

Demo inference output:

```json
{
  "session_id": "iob-ds-demo-1285",
  "decision": "ACCESS_DENIED",
  "risk_level": "CRITICAL",
  "trust_score": 18,
  "fraud_probability": 94,
  "detected_attack": "deepfake_or_spoof",
  "signals": {
    "gan_artifacts": "anomaly",
    "face_warping": "anomaly",
    "eye_reflection": "anomaly",
    "lip_sync_mismatch": "anomaly",
    "replay_surface": "anomaly",
    "synthetic_texture": "anomaly",
    "rppg_pulse_lock": false,
    "device_trust": "low"
  },
  "security_action": "Block login, freeze high-risk transaction, send event to admin dashboard"
}
```

Expected trained-model targets for a real build:

- Deepfake classifier accuracy: 92% to 97% on curated validation data.
- Anti-spoof classifier: detects photo, screen replay, mask, virtual camera, and AI avatar attempts.
- rPPG liveness: confirms pulse only when face tracking and frame quality are stable.
- Risk engine: fuses face, liveness, pulse, device, geo, and behavior signals into one score.

## What The App Does

IOB DeepShield is an AI-powered banking authentication platform that checks whether the user is a real live human before allowing login or high-value banking actions.

Core modules:

- AI face authentication.
- Dynamic liveness detection.
- Deepfake and GAN artifact detection.
- Printed-photo, replay, mask, virtual-camera, and AI-avatar anti-spoofing.
- Webcam-based rPPG heartbeat verification.
- Fraud risk engine with trust score and fraud probability.
- Admin dashboard for suspicious login events.
- Banking use cases for IOB login, UPI, ATM, and transaction verification.

## Frontend Pages And Sections

Current implemented prototype:

- Futuristic hero and product pitch.
- Real user demo button.
- Spoof attack demo button.
- Animated AI face scanner.
- Liveness prompt sequence.
- Trust score and fraud probability rings.
- Deepfake signal analysis panel.
- Heartbeat and behavior engine panel.
- Banking security actions panel.
- Admin fraud dashboard.
- Technical architecture section.
- Backend API, AI pipeline, and database schema summary.

## Suggested Folder Structure For Full Product

```text
deepshield-iob/
  frontend/
    src/
      pages/
      components/
      hooks/
      services/
      utils/
  backend/
    app/
      api/
      core/
      models/
      schemas/
      services/
      security/
  ai/
    datasets/
    notebooks/
    training/
    inference/
    weights/
  database/
    migrations/
    seed/
  docs/
```

## Backend API Plan

- `POST /api/auth/start-session`: create secure verification session.
- `POST /api/vision/liveness-frame`: process webcam frame and liveness prompt result.
- `POST /api/ai/deepfake-score`: return deepfake probability and artifact flags.
- `POST /api/biometric/rppg-pulse`: estimate pulse confidence from face regions.
- `POST /api/risk/evaluate`: combine all signals into trust score and final decision.
- `GET /api/admin/fraud-events`: show suspicious attempts to bank security team.

## AI Pipeline

1. Capture camera frame and run quality checks.
2. Detect face and landmarks with MediaPipe or OpenCV.
3. Verify liveness prompt response timing and natural movement.
4. Extract frame crops for deepfake classifier.
5. Analyze GAN texture, warping, reflection, lip sync, and replay artifacts.
6. Extract rPPG pulse from cheek and forehead regions.
7. Add device trust, geolocation anomaly, voice match, and behavior signals.
8. Generate trust score, fraud probability, risk level, and explainability flags.

## Database Schema

- `users`: customer identity, encrypted face embedding, voiceprint hash, trusted devices.
- `verification_sessions`: session id, customer id, trust score, risk level, decision.
- `liveness_events`: prompts, response time, pass/fail, landmark metrics.
- `fraud_events`: attack type, probability, region, device, blocked timestamp.
- `audit_logs`: encrypted event payload, admin action, blockchain verification hash.

## Security Design

- JWT-secured APIs.
- Encrypted biometric templates.
- HTTPS-only banking session.
- Device binding and session monitoring.
- Admin audit logs.
- Step-up authentication for medium-risk attempts.
- Block and alert workflow for critical-risk attempts.

## Deployment Plan

Frontend:

- Build with `npm run build`.
- Host `dist/` on Vercel, Netlify, Firebase Hosting, or bank-controlled static hosting.

Backend:

- FastAPI with Uvicorn or Gunicorn.
- Docker container with OpenCV, TensorFlow or PyTorch, MediaPipe, and DeepFace.
- Deploy to AWS, Azure, GCP, Render, or bank private cloud.

Database:

- PostgreSQL for structured banking events.
- MongoDB for flexible AI reports and frame-level metadata.
- Object storage for encrypted evidence snapshots when policy allows it.

## Best Demo Flow

1. Open local app link.
2. Click `Demo real user`.
3. Show `Access granted`, high trust score, and low fraud probability.
4. Click `Demo spoof attack`.
5. Show `Access denied`, critical risk, and deepfake/spoof detection.
6. Scroll to admin dashboard and explain blocked attempts.
7. Scroll to architecture and explain how the full AI backend would be built.
