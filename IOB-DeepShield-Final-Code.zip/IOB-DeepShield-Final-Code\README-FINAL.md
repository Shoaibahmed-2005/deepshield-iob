# IOB DeepShield Final Code

This folder contains the complete frontend code for the IOB DeepShield / VID-LIVE hackathon app.

## Run

```bash
npm install
npm run dev -- --host 127.0.0.1 --port 5173
```

Open:

```txt
http://127.0.0.1:5173/
```

## Build

```bash
npm run build
```

## Included

- React + TypeScript + Vite frontend
- Real webcam preview using WebRTC
- MediaPipe FaceMesh liveness tracking
- Head movement/parallax scoring
- Blink and smile checks
- rPPG-style pulse confidence estimate
- Anti-spoof/deepfake risk scoring
- Trust score and fraud probability JSON output
- IOB and DeepShield logos
- Dark blue cyber UI with 3D hover and glow effects

## Not Included

- `node_modules`
- A real backend server
- A trained CNN-LSTM/Transformer deepfake model

Backend/model integration can be added later using FastAPI, OpenCV, MediaPipe, and PyTorch/TensorFlow.
